package com.amaysim.shoppingcart.vo;

import java.math.BigDecimal;

public class Product {

	String productCode;
	BigDecimal price;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	
	
}
